#ifndef VERSION_H_
#define VERSION_H_

#define PROGRAM_NAME "ue"
#define PROGRAM_NAME_LONG "uEmacs/Pk/Er"

#define	VERSION	"4.0.16"

/* Print the version string. */
void version(void);

#endif  /* VERSION_H_ */
