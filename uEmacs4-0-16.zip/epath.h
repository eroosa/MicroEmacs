/*	EPATH.H
 *
 *	This file contains certain info needed to locate the
 *	initialization (etc) files on a system dependent basis
 *
 *	modified by Petri Kutvonen
 */
#ifndef EPATH_H_
#define EPATH_H_

/*	possible names and paths of help files under different OSs	*/
static char *pathname[] =
#if	MSDOS
{
	"emacs.rc",
	"emacs.hlp",
	"\\sys\\public\\",
	"\\usr\\bin\\",
	"\\bin\\",
	"\\",
	""
};
#endif

/* er:  this seemed like fair game, so i fiddled with it.
    the rule is (for anyone new to the game), emacs looks for the
    two listed files anywhere along the path; the only files that
    matter are the first versions found.
    N.B.:  ~/ and ./ are always checked before this list.
*/
#if	V7 | BSD | USG
{
	".emacsrc",
	"emacs.hlp",
#if	PKCODE
	"/usr/local/bin/",
    "/usr/local/lib/",
#endif
	"/usr/lib/",
	"/usr/local/",
	"/usr/global/lib/"
};
#endif

#if	VMS
{
	"emacs.rc", "emacs.hlp", "",
#if	PKCODE
	    "sys$login:", "emacs_dir:",
#endif
"sys$sysdevice:[vmstools]"};
#endif

#endif  /* EPATH_H_ */
