#ifndef UTIL_H_
#define UTIL_H_

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
void mystrscpy(char *dst, const char *src, int size);

#endif  /* UTIL_H_ */
