#ifndef VERSION_H_
#define VERSION_H_

#define PROGRAM_NAME "ue"
#define PROGRAM_NAME_LONG "uEmacs/PK/ER"

#define	VERSION	"4.0.17"
#define	BUILD	"20260812_33_15:26:10"
/*
    the version i pulled from github was called 'em', version 4.0.15.
    i renamed it ue (in Makefile) so building wouldn't overwrite the 
    old version.  that became 4.0.16, compiled with reasonable warnings
    on ubuntu 24.  gcc on termux is less forgiving than gcc on ubuntu,
    so we needed a couple of headers, and a proper rewrite of instime,
    and 'cuserid' is a hard no.  hence, v. 4.0.17.
*/
/* Print the version string. */
void version(void);

#endif  /* VERSION_H_ */
